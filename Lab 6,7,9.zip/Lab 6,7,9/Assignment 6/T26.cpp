#include<iostream>
using namespace std;

int main()
{
  int a = 30;
  a << 3;
  cout << a << endl;
  int b = a & 6;
  cout << b << endl;



    return 0;
}