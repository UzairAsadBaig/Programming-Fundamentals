#include <iostream>
#include<cmath>
using namespace std;


int main()
{

int a=60,b=7;
cout<<"Sum is : "<<a+b<<endl;
cout<<"Difference is : "<<a-b<<endl;
cout<<"Product is : "<<a*b<<endl;
cout<<"Quotient is : "<<a/b<<endl;
int c=a%b;
cout<<"The remainder is : "<<c<<endl;


    return 0;
}