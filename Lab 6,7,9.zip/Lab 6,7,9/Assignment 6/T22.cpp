#include <iostream>
using namespace std;

int main()
{
  char x;
  x='\a';
  cout<<x<<endl;



    return 0;
}